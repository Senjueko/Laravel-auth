<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Project;
use Illuminate\Http\Request;

class ProjectController extends Controller
{
    public function createProject(Request $request){
        $request->validate([
            "name" => "required",
            "description" => "required",
            "duration" => "required",
        ]);

        $student_id = auth()->user()->id;

        $project = new Project();

        $project->name = $request->name;
        $project->description = $request->description;
        $project->duration = $request->duration;
        $project->student_id = $student_id;

        $project->save();

        return response()->json([
            "status" => "success",
            "message" => "Project has been Created",
        ], 200);
    }

    public function listProject(){
        $student_id = auth()->user()->id;

        $projects = Project::where("student_id","=","$student_id")->get();

        return response()->json([
            "status" => "success",
            "message" => "Projects",
            "data" => $projects
        ], 200);
    }

    public function singleProject($id){

        $student_id = auth()->user()->id;

       if (Project::where(["id"=> $id, "student_id" => $student_id])->exists()){
           $project = Project::where(["id"=> $id, "student_id" => $student_id])->get();
           return response()->json([
               "status" => "success",
               "message" => "single Project:",
               "data" => $project
           ], 200);
       }
       else{
           return response()->json([
               "status" => "success",
               "message" => "Project not found",
           ], 200);
       }

    }

    public function deleteProject($id){
        $student_id = auth()->user()->id;

        if (Project::where(["id"=> $id, "student_id" => $student_id])->exists()){
            $project = Project::where(["id"=> $id, "student_id" => $student_id])->first();
            $project->delete();
            return response()->json([
                "status" => "success",
                "message" => "Project deleted:",
            ], 200);
        }
        else{
            return response()->json([
                "status" => "success",
                "message" => "Project not found",
            ], 200);
        }
    }
}
