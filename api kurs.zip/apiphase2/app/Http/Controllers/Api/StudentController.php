<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Student;
use http\Env\Response;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class StudentController extends Controller
{
    public function register(Request $request){
        $request->validate([
            "name" => "required",
            "email" => "required|email|unique:students",
            "password" => "required|confirmed",
        ]);

        $student = new Student();

        $student->name = $request->name;
        $student->email = $request->email;
        $student->password = Hash::make($request->password);
        $student->phone_no = $request->phone_no ?? "";

        $student->save();

        return response()->json([
            "status" => "success",
            "message" => "Student Registered",
        ], 200);
    }

    public function login(Request $request){
        $request->validate([
            "email" => "required|email",
            "password" => "required"
        ]);

        $student = Student::where("email", "=", $request->email)->first();
        if (isset($student->id)) {
            if (Hash::check($request->password,$student->password)){
                $token = $student->createToken("auth_token")->plainTextToken;
                return response()->json([
                    "status" => "success",
                    "message" => "Student logged in",
                    "access_token" => $token
                ],200);
            }
            else{
                return response()->json([
                    "status" => "success",
                    "message" => "Student password did not match",
                ],200);
            }
        }
        else {
            return response()->json([
                "status" => "success",
                "message" => "Student Could not found",
            ],200);
        }
    }

    public function profile(){
        return response()->json([
            "status" => "success",
            "message" => "Student logged in",
            "access_token" => auth()->user()
        ],200);
    }

    public function logout(){
        auth()->user()->tokens()->delete();

        return response()->json([
            "status" => "success",
            "message" => "Student logged out",
        ],200);
    }
}
