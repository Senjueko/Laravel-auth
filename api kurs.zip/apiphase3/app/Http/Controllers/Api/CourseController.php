<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Course;
use App\Models\User;
use Illuminate\Http\Request;

class CourseController extends Controller
{
    public function courseEnrollment(Request $request){
        $request->validate([
            "title" => "required",
            "description" => "required",
            "total_videos" => "required",
        ]);

        $user_id = auth()->user()->id;

        $course = new Course();

        $course->title = $request->title;
        $course->description = $request->description;
        $course->total_videos = $request->total_videos;
        $course->user_id = $user_id;

        $course->save();

        return response()->json([
            "status" => "success",
            "message" => "Course has been enrolled"
        ],200);
    }

    public function totalCourses(){
        $id = auth()->user()->id;

        $courses = User::find($id)->courses;

        return response()->json([
            "status" => "success",
            "message" => "Total Courses",
            "data" => $courses
        ],200);
    }

    public function deleteCourse($id){
        $user_id = auth()->user()->id;

        if (Course::where(["id" => $id, "user_id" => $user_id])->exists()){
            Course::destroy($id);

            return response()->json([
                "status" => "success",
                "message" => "Course has been deleted",

            ],200);
        }
        else{
            return response()->json([
                "status" => "success",
                "message" => "Course has not been found",

            ],200);
        }
    }
}
