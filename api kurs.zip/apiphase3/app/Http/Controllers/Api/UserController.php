<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;

class UserController extends Controller
{
    public function register(Request $request){
        $request->validate([
            "name" => "required",
            "email" => "required|email|unique:users",
            "phone_no" => "required",
            "password" => "required|confirmed",
        ]);

        $user = new User();

        $user->name = $request->name;
        $user->email = $request->email;
        $user->phone_no = $request->phone_no;
        $user->password = bcrypt($request->password);

        $user->save();

        return response()->json([
            "status" => "success",
            "message" => "User registered"
        ],200);
    }

    public function login(Request $request){
        $request->validate([
            "email" => "required",
            "password" => "required",
        ]);

        if (!$token = auth()->attempt(["email" => $request->email, "password" => $request->password])){
            return response()->json([
                "status" => "success",
                "message" => "Invalid credentials"
            ],200);
        }
        return response()->json([
            "status" => "success",
            "message" => "Logged In",
            "access_token" => $token
        ],200);

    }

    public function profile(){
        $user_data = auth()->user();

        return response()->json([
            "status" => "success",
            "message" => "User Profile data",
            "access_token" => $user_data
        ],200);
    }

    public function logout(){
        auth()->logout();

        return response()->json([
            "status" => "success",
            "message" => "Logged Out",
        ],200);
    }
}
